#!/bin/bash

# Zyprexa Survivors Guide - Quick Deployment Script
# This script helps you deploy the application to various platforms

set -e

echo "🚀 Zyprexa Survivors Guide Deployment Script"
echo "============================================="

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 18+ first."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm first."
    exit 1
fi

echo "✅ Node.js and npm are installed"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Build the application
echo "🔨 Building the application..."
npm run build

# Check if build was successful
if [ ! -d ".next" ]; then
    echo "❌ Build failed. .next directory not found."
    exit 1
fi

echo "✅ Build successful"

# Ask for deployment platform
echo ""
echo "🎯 Choose your deployment platform:"
echo "1) Vercel (Recommended)"
echo "2) Netlify"
echo "3) Railway"
echo "4) DigitalOcean App Platform"
echo "5) Self-hosted VPS"
echo "6) Exit"
echo ""
read -p "Enter your choice (1-6): " choice

case $choice in
    1)
        echo "🌐 Deploying to Vercel..."
        echo "Steps to deploy to Vercel:"
        echo "1. Make sure you have a GitHub repository"
        echo "2. Go to vercel.com and connect your repository"
        echo "3. Vercel will automatically detect Next.js and deploy"
        echo ""
        echo "📋 Prerequisites:"
        echo "- GitHub account"
        echo "- Repository pushed to GitHub"
        echo "- Vercel account"
        echo ""
        read -p "Press Enter to continue or Ctrl+C to exit..."
        
        # Check if git is initialized
        if [ ! -d ".git" ]; then
            echo "🔧 Initializing git repository..."
            git init
            git add .
            git commit -m "Initial commit"
            echo "✅ Git repository initialized"
            echo "📤 Don't forget to push to GitHub and connect to Vercel!"
        else
            echo "✅ Git repository already exists"
            echo "📤 Make sure to push latest changes to GitHub and connect to Vercel!"
        fi
        ;;
        
    2)
        echo "🌐 Deploying to Netlify..."
        echo "Steps to deploy to Netlify:"
        echo "1. Go to netlify.com"
        echo "2. Drag and drop the .next folder or connect Git repository"
        echo "3. Configure build settings if needed"
        echo ""
        echo "📋 Prerequisites:"
        echo "- Netlify account"
        echo "- Built application (ready in .next folder)"
        echo ""
        read -p "Press Enter to continue or Ctrl+C to exit..."
        ;;
        
    3)
        echo "🚂 Deploying to Railway..."
        echo "Steps to deploy to Railway:"
        echo "1. Install Railway CLI: npm install -g @railway/cli"
        echo "2. Login: railway login"
        echo "3. Initialize: railway init"
        echo "4. Deploy: railway up"
        echo ""
        echo "📋 Prerequisites:"
        echo "- Railway account"
        echo "- Railway CLI installed"
        echo ""
        read -p "Do you have Railway CLI installed? (y/n): " railway_cli
        if [ "$railway_cli" = "y" ]; then
            echo "🚀 Starting Railway deployment..."
            railway login
            railway init
            railway up
        else
            echo "Please install Railway CLI first: npm install -g @railway/cli"
        fi
        ;;
        
    4)
        echo "☁️ Deploying to DigitalOcean App Platform..."
        echo "Steps to deploy to DigitalOcean:"
        echo "1. Push your code to GitHub"
        echo "2. Go to DigitalOcean App Platform"
        echo "3. Create new app and connect GitHub repository"
        echo "4. Configure build settings"
        echo ""
        echo "📋 Prerequisites:"
        echo "- DigitalOcean account"
        echo "- GitHub repository"
        echo ""
        read -p "Press Enter to continue or Ctrl+C to exit..."
        ;;
        
    5)
        echo "🖥️ Self-hosted VPS deployment..."
        echo "This option requires a VPS with Ubuntu/Debian"
        echo ""
        echo "📋 Prerequisites:"
        echo "- VPS server (Ubuntu/Debian recommended)"
        echo "- Domain name (optional)"
        echo "- SSH access to server"
        echo ""
        read -p "Do you have server details ready? (y/n): " server_ready
        
        if [ "$server_ready" = "y" ]; then
            echo "📝 Creating deployment package..."
            tar -czf zyprexa-survivors-guide.tar.gz .next public package.json package-lock.json
            
            echo "📦 Package created: zyprexa-survivors-guide.tar.gz"
            echo ""
            echo "🚀 Next steps for server deployment:"
            echo "1. Copy the package to your server:"
            echo "   scp zyprexa-survivors-guide.tar.gz user@your-server:/path/to/deploy/"
            echo ""
            echo "2. SSH into your server and extract:"
            echo "   ssh user@your-server"
            echo "   cd /path/to/deploy"
            echo "   tar -xzf zyprexa-survivors-guide.tar.gz"
            echo ""
            echo "3. Install Node.js and dependencies:"
            echo "   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -"
            echo "   sudo apt-get install -y nodejs"
            echo "   npm install"
            echo ""
            echo "4. Install PM2 and start the application:"
            echo "   sudo npm install -g pm2"
            echo "   pm2 start server.ts --name 'zyprexa-guide'"
            echo ""
            echo "5. Set up Nginx reverse proxy (recommended)"
            echo ""
        else
            echo "Please prepare your server details first."
        fi
        ;;
        
    6)
        echo "👋 Exiting deployment script."
        exit 0
        ;;
        
    *)
        echo "❌ Invalid choice. Please select 1-6."
        exit 1
        ;;
esac

echo ""
echo "🎉 Deployment preparation complete!"
echo ""
echo "📚 Additional resources:"
echo "- Full deployment guide: DEPLOYMENT-GUIDE.md"
echo "- Next.js documentation: https://nextjs.org/docs"
echo "- Troubleshooting: Check the deployment guide for common issues"
echo ""
echo "📞 Need help?"
echo "- Check the deployment guide for detailed instructions"
echo "- Review platform-specific documentation"
echo "- Contact support if needed"
echo ""
echo "✨ Thank you for deploying the Zyprexa Survivors Guide!"