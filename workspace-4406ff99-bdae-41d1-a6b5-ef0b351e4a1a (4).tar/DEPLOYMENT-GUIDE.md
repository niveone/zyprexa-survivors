# Zyprexa Survivors Guide - Deployment Guide

This comprehensive guide will help you deploy your Next.js Zyprexa Survivors Guide application to various platforms. The application is a production-ready Next.js 15 application with TypeScript, Tailwind CSS, and shadcn/ui components.

## Prerequisites

Before deploying, ensure you have:
- Node.js 18+ installed
- All project dependencies installed (`npm install`)
- A Git repository (recommended for most platforms)
- Database setup (if using Prisma features)

## Deployment Options

### 1. Vercel (Recommended for Next.js)

Vercel is the optimal platform for Next.js applications, offering seamless deployment and automatic optimizations.

#### Steps:
1. **Push to GitHub/GitLab**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/your-username/zyprexa-survivors-guide.git
   git push -u origin main
   ```

2. **Deploy to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Sign up and click "New Project"
   - Import your GitHub repository
   - Configure build settings (Vercel auto-detects Next.js)
   - Click "Deploy"

3. **Environment Variables** (if needed)
   ```bash
   # In Vercel dashboard > Settings > Environment Variables
   NODE_ENV=production
   DATABASE_URL=your_database_url
   ```

4. **Custom Domain** (optional)
   - In Vercel dashboard > Settings > Domains
   - Add your custom domain

**Advantages**: Automatic SSL, CDN, edge caching, serverless functions
**Cost**: Free tier available, paid plans start at $20/month

### 2. Netlify

Netlify is another excellent option with great CI/CD integration.

#### Steps:
1. **Build the application**
   ```bash
   npm run build
   ```

2. **Deploy via Drag & Drop**
   - Go to [netlify.com](https://netlify.com)
   - Drag the `.next` folder and `public` folder to the drop zone
   - Or connect your Git repository

3. **Configure Build Settings** (if using Git)
   ```yaml
   Build command: npm run build
   Publish directory: .next
   Node version: 18
   ```

4. **Environment Variables**
   - In Netlify dashboard > Site settings > Build & deploy > Environment
   - Add required variables

**Advantages**: Free SSL, form handling, serverless functions
**Cost**: Free tier available, paid plans start at $19/month

### 3. DigitalOcean App Platform

DigitalOcean offers a robust PaaS solution with good performance.

#### Steps:
1. **Prepare your app**
   ```bash
   npm run build
   ```

2. **Create appspec.yml**
   ```yaml
   name: zyprexa-survivors-guide
   services:
   - name: web
     source_dir: /
     github:
       repo: your-username/zyprexa-survivors-guide
       branch: main
     run_command: npm start
     environment_slug: node-js
     instance_count: 1
     instance_size_slug: basic-xxs
     envs:
     - key: NODE_ENV
       value: production
     - key: DATABASE_URL
       value: ${db.DATABASE_URL}
   databases:
   - name: db
     engine: PG
     version: "13"
     size: db-s-dev-database
     num_nodes: 1
   ```

3. **Deploy via DigitalOcean dashboard**
   - Go to DigitalOcean App Platform
   - Create new app
   - Connect your GitHub repository
   - Upload or create appspec.yml

**Advantages**: Scalable, good performance, includes database options
**Cost**: Starts at $5/month (includes free tier)

### 4. AWS Amplify

AWS Amplify provides a complete CI/CD pipeline for web applications.

#### Steps:
1. **Connect to AWS Amplify Console**
   - Go to AWS Management Console > Amplify
   - Click "New app" > "Host web app"

2. **Connect repository**
   - Choose GitHub repository
   - Select your repository and branch

3. **Configure build settings**
   ```yaml
   version: 1
   frontend:
     phases:
       preBuild:
         commands:
           - npm ci
       build:
         commands:
           - npm run build
     artifacts:
       baseDirectory: .next
       files:
         - '**/*'
     cache:
       paths:
         - node_modules/**/*
   ```

4. **Environment Variables**
   - In Amplify console > App settings > Environment variables
   - Add required variables

**Advantages**: Full AWS integration, scalable, secure
**Cost**: Free tier available, paid usage-based pricing

### 5. Self-hosted VPS/Dedicated Server

For full control, you can deploy to your own server.

#### Steps:
1. **Server Setup (Ubuntu/Debian)**
   ```bash
   # Update system
   sudo apt update && sudo apt upgrade -y
   
   # Install Node.js
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   
   # Install PM2 (process manager)
   sudo npm install -g pm2
   ```

2. **Deploy Application**
   ```bash
   # Clone repository
   git clone https://github.com/your-username/zyprexa-survivors-guide.git
   cd zyprexa-survivors-guide
   
   # Install dependencies
   npm install
   
   # Build application
   npm run build
   
   # Start with PM2
   pm2 start server.ts --name "zyprexa-guide"
   pm2 save
   pm2 startup
   ```

3. **Setup Nginx Reverse Proxy**
   ```bash
   sudo apt install nginx
   sudo nano /etc/nginx/sites-available/zyprexa-guide
   ```

   ```nginx
   server {
       listen 80;
       server_name your-domain.com;
       
       location / {
           proxy_pass http://localhost:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

   ```bash
   sudo ln -s /etc/nginx/sites-available/zyprexa-guide /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx
   ```

4. **Setup SSL with Let's Encrypt**
   ```bash
   sudo apt install certbot python3-certbot-nginx
   sudo certbot --nginx -d your-domain.com
   ```

**Advantages**: Full control, potentially cheaper long-term
**Cost**: VPS starting from $5/month (DigitalOcean, Linode, Vultr)

### 6. Railway

Railway is a modern deployment platform with excellent developer experience.

#### Steps:
1. **Install Railway CLI**
   ```bash
   npm install -g @railway/cli
   ```

2. **Login and Initialize**
   ```bash
   railway login
   railway init
   ```

3. **Configure Environment**
   ```bash
   railway add NODE_ENV=production
   railway add DATABASE_URL=your_database_url
   ```

4. **Deploy**
   ```bash
   railway up
   ```

**Advantages**: Easy setup, good developer experience, automatic scaling
**Cost**: Free tier available, paid plans start at $5/month

### 7. Render

Render is a unified cloud platform for building and running apps.

#### Steps:
1. **Connect to Render**
   - Go to [render.com](https://render.com)
   - Sign up and click "New +"
   - Select "Web Service"

2. **Configure Service**
   - Connect your GitHub repository
   - Set runtime: Node
   - Build command: `npm run build`
   - Start command: `npm start`
   - Instance type: Free (starter)

3. **Environment Variables**
   - In Render dashboard > Environment
   - Add required variables

**Advantages**: Free SSL, private networks, easy scaling
**Cost**: Free tier available, paid plans start at $7/month

## Production Build Checklist

Before deploying to production, ensure:

### 1. Optimize Build
```bash
# Run production build
npm run build

# Check for errors
npm run lint
```

### 2. Environment Variables
Create `.env.production`:
```env
NODE_ENV=production
DATABASE_URL=your_production_database_url
NEXTAUTH_URL=https://your-domain.com
NEXTAUTH_SECRET=your_secret_key
```

### 3. Security Considerations
- [ ] Remove development dependencies from production
- [ ] Set up proper environment variables
- [ ] Configure CORS if needed
- [ ] Set up rate limiting
- [ ] Enable HTTPS
- [ ] Secure database connections

### 4. Performance Optimization
- [ ] Enable compression (gzip/brotli)
- [ ] Set up proper caching headers
- [ ] Optimize images
- [ ] Use CDN for static assets
- [ ] Monitor performance metrics

### 5. Monitoring and Logging
- [ ] Set up error monitoring (Sentry, etc.)
- [ ] Configure logging
- [ ] Set up health checks
- [ ] Monitor uptime and performance

## Database Setup (if using Prisma)

### 1. Production Database
```bash
# Generate Prisma client
npm run db:generate

# Push schema to production database
npm run db:push

# Or use migrations
npm run db:migrate
```

### 2. Database Providers
- **Supabase**: Free PostgreSQL with generous limits
- **PlanetScale**: MySQL-compatible, good for scaling
- **Railway**: Built-in database options
- **DigitalOcean**: Managed PostgreSQL databases

## Domain and DNS Configuration

### 1. Domain Registration
- Purchase domain from Namecheap, GoDaddy, or Cloudflare

### 2. DNS Configuration
```
Type: A
Name: @
Value: your_server_ip

Type: CNAME
Name: www
Value: your-domain.com
```

### 3. SSL Certificate
- Most platforms provide automatic SSL
- For self-hosted: Use Let's Encrypt

## Post-Deployment Tasks

### 1. Testing
```bash
# Test production build locally
npm run build
npm start

# Run production tests
npm test:prod
```

### 2. Monitoring Setup
- Google Analytics for traffic
- Uptime monitoring (UptimeRobot, Pingdom)
- Error tracking (Sentry, Bugsnag)

### 3. Backup Strategy
- Regular database backups
- Code repository backups
- Asset backups

## Troubleshooting Common Issues

### 1. Build Errors
```bash
# Clear Next.js cache
rm -rf .next
npm run build

# Update dependencies
npm update
```

### 2. Runtime Errors
```bash
# Check logs
pm2 logs zyprexa-guide

# Restart application
pm2 restart zyprexa-guide
```

### 3. Database Connection Issues
- Verify DATABASE_URL
- Check database server status
- Test connection locally

## Recommended Deployment Stack

### For Most Users: Vercel
- **Why**: Best Next.js integration, automatic optimizations
- **Cost**: Free tier available
- **Setup**: 5 minutes

### For Budget-Conscious: Netlify + Supabase
- **Why**: Free tier for both hosting and database
- **Cost**: $0 for small projects
- **Setup**: 10 minutes

### For Enterprise: AWS Amplify
- **Why**: Full AWS integration, scalable
- **Cost**: Usage-based
- **Setup**: 15 minutes

### For Full Control: DigitalOcean VPS
- **Why**: Complete control over environment
- **Cost**: $5/month starting
- **Setup**: 30 minutes

## Support and Resources

- **Next.js Documentation**: [nextjs.org/docs](https://nextjs.org/docs)
- **Vercel Documentation**: [vercel.com/docs](https://vercel.com/docs)
- **Deployment Issues**: GitHub Discussions
- **Community Support**: Stack Overflow, Discord

## Conclusion

Your Zyprexa Survivors Guide application is ready for production deployment. Choose the deployment method that best fits your needs, budget, and technical expertise. For most users, Vercel provides the best balance of ease-of-use and performance.

Remember to:
1. Test thoroughly before going live
2. Set up monitoring and backups
3. Keep dependencies updated
4. Follow security best practices

Good luck with your deployment!