# ZYPREXA SURVIVORS: QUICK REFERENCE GUIDE
## Action-Oriented Checklist for Recovery & Advocacy

---

## 🚨 IMMEDIATE ACTIONS (Start Today)

### Medical Documentation
- [ ] **Collect all Zyprexa-related medical records**
- [ ] **Create detailed timeline**: When started/stopped, dosage, side effects
- [ ] **Begin symptom journal**: Track physical, cognitive, emotional symptoms daily
- [ ] **Take "before/after" photos**: Document physical changes

### Initial Medical Consultation
- [ ] **Find knowledgeable doctor**: Look for metabolic psychiatry or functional medicine
- [ ] **Prepare consultation script**:
  > "I experienced long-term effects from Zyprexa including [list symptoms]. 
  > Based on research showing receptor downregulation and metabolic damage, 
  > I'd like to discuss betahistine, metabolic testing, and recovery options."

---

## 📋 UNDERSTANDING YOUR SYMPTOMS

### Common Zyprexa Damage Symptoms
**Metabolic:**
- Rapid weight gain (especially abdominal)
- Insulin resistance / Type 2 diabetes
- High triglycerides / cholesterol
- Fatigue and low energy

**Neurological:**
- Emotional numbness / anhedonia
- Loss of pleasure from previously enjoyed activities
- Inability to feel effects of alcohol, cannabis, psychedelics
- Cognitive fog / memory issues
- Movement problems (tremors, restlessness)

**Psychological:**
- Depression and anxiety
- Loss of motivation
- Social withdrawal
- Sleep disturbances

---

## 💊 TREATMENT PROTOCOL CHECKLIST

### Phase 1: Foundation (First 3 Months)
- [ ] **Betahistine**: Ask doctor for prescription (off-label use)
- [ ] **GLP-1 Agonist**: Discuss semaglutide/liraglutide with doctor
- [ ] **Ketogenic Diet**: Start immediately
  - Eliminate sugar and refined carbs
  - Increase healthy fats (avocado, olive oil, coconut)
  - Moderate protein intake
  - Try 16:8 intermittent fasting
- [ ] **Basic Supplements**:
  - L-Tyrosine: 1000-2000mg daily
  - Omega-3: 2000-3000mg EPA/DHA daily
  - Magnesium: 400mg daily
  - Vitamin D3: 2000-5000 IU daily

### Phase 2: Neuroplasticity (Months 3-6)
- [ ] **Ketamine Therapy**: Research clinical trials or specialized clinics
- [ ] **Methylphenidate Trial**: Discuss low-dose diagnostic use with doctor
- [ ] **Advanced Supplements**:
  - Alpha-GPC: 300-600mg daily
  - N-Acetylcysteine (NAC): 600-1200mg daily
  - Lions Mane Mushroom: 1000mg daily

### Phase 3: Advanced Recovery (Months 6+)
- [ ] **Psychedelic Therapy**: Under professional guidance, if appropriate
- [ ] **Epigenetic Testing**: Explore DNA methylation testing
- [ ] **Advanced Imaging**: Consider PET scans for receptor density

---

## 🏥 MEDICAL TESTING CHECKLIST

### Essential Tests
- [ ] **Comprehensive Metabolic Panel**: Glucose, insulin, HbA1c
- [ ] **Lipid Panel**: Triglycerides, cholesterol, HDL/LDL
- [ ] **Hormone Panel**: Thyroid, cortisol, sex hormones
- [ ] **Inflammation Markers**: CRP, homocysteine
- [ ] **Nutrient Levels**: Vitamin D, B12, magnesium, zinc

### Advanced Testing (If Accessible)
- [ ] **PET Scan**: Receptor density and function
- [ ] **Metabolic Rate Testing**: Resting energy expenditure
- [ ] **Epigenetic Testing**: DNA methylation patterns
- [ ] **Mitochondrial Function**: Organic acids test

---

## ⚖️ LEGAL ACTION CHECKLIST

### Documentation
- [ ] **Organize medical records** chronologically
- [ ] **Create impact statement**: How Zyprexa affected your life
- [ ] **Document financial costs**: Medical bills, lost wages, care expenses
- [ ] **Gather witness statements**: Family, friends, coworkers

### Reporting
- [ ] **File adverse event report** with national regulatory agency
- [ ] **Submit to European Medicines Agency** (if in EU)
- [ ] **Report to RxISK.org**: International side effect database
- [ ] **Keep copies with reference numbers**

### Legal Consultation
- [ ] **Research pharmaceutical litigation attorneys**
- [ ] **Prepare questions for lawyer**:
  - Experience with Zyprexa cases?
  - Success rate with similar cases?
  - Fee structure (contingency preferred)?
  - Statute of limitations considerations?

---

## 📢 ADVOCACY CHECKLIST

### Personal Advocacy
- [ ] **Create social media presence**:
  - Twitter/X: Share research and updates
  - Facebook: Connect with other survivors
  - Instagram: Document recovery journey
- [ ] **Start blog or website**: Share your story and resources
- [ ] **Use consistent hashtags**: #ZyprexaSurvivor #PharmaAccountability #AntipsychoticHarm

### Community Building
- [ ] **Find other survivors**: Online forums, support groups
- [ ] **Start local support group**: Meetup.com, local mental health organizations
- [ ] **Partner with advocates**: Connect with existing organizations

### Media Outreach
- [ ] **Research journalists**: Those covering pharmaceutical issues
- [ ] **Prepare press kit**: Your story, research summary, contact info
- [ ] **Pitch story**: Focus on human impact and scientific evidence

---

## 🎯 RECOVERY TRACKING

### Weekly Check-in
**Physical Symptoms:**
- Energy level (1-10): ___
- Pain/discomfort (1-10): ___
- Sleep quality (1-10): ___
- Weight: ___

**Mental/Emotional:**
- Mood (1-10): ___
- Anxiety (1-10): ___
- Mental clarity (1-10): ___
- Motivation (1-10): ___

**Treatment Response:**
- New symptoms: _________________________
- Improvements: _________________________
- Side effects: _________________________

### Monthly Assessment
- [ ] **Review symptom journal**: Identify patterns and progress
- [ ] **Adjust treatments**: Based on response and new research
- [ ] **Update doctors**: Share progress and concerns
- [ ] **Celebrate wins**: Acknowledge any improvements

---

## 📚 ESSENTIAL RESOURCES

### Must-Read Research
- **"Effects of olanzapine and betahistine co-treatment"** (PMID: 23994047)
- **GLP-1 agonists for antipsychotic-induced weight gain** (PMID: 28601891)
- **Antipsychotic-induced brain volume changes** (Journal of Psychiatric Research)

### Key Organizations
- **Mad in America**: News and resources for psychiatric medication reform
- **RxISK**: Prescription drug side effect reporting
- **PsychRights**: Legal advocacy for mental health rights
- **Health Action International**: Rational drug use advocacy

### Online Communities
- **Reddit**: r/psychiatry, r/antipsychotics, r/medical_advice
- **Facebook**: Zyprexa support groups, psychiatric medication survivor groups
- **Twitter/X**: Follow #Zyprexa, #antipsychotic, #mentalhealth advocates

---

## 🚨 RED FLAGS - WHEN TO SEEK IMMEDIATE HELP

### Medical Emergency
- **Suicidal thoughts**: Call emergency services or crisis line
- **Severe movement problems**: Difficulty speaking or swallowing
- **Extreme blood sugar changes**: Confusion, loss of consciousness
- **Neuroleptic Malignant Syndrome**: High fever, muscle rigidity, confusion

### Legal Emergency
- **Statute of limitations approaching**: Consult attorney immediately
- **Evidence being destroyed**: Preserve records and documentation
- **Retaliation from employers/insurers**: Document and report

---

## 📈 SUCCESS METRICS

### Recovery Indicators
- **Improved energy levels**: Sustained throughout the day
- **Return of emotional responsiveness**: Ability to feel joy, sadness, excitement
- **Cognitive improvement**: Better memory, focus, processing speed
- **Metabolic normalization**: Stable blood sugar, healthy weight
- **Social reconnection**: Desire and ability to engage with others

### Advocacy Indicators
- **Growing network**: Connections with other survivors and advocates
- **Media attention**: Your story being shared and discussed
- **Policy impact**: Contributing to regulatory changes or warnings
- **Community building**: Helping other survivors on their journey

---

## 📝 QUICK TEMPLATES

### Doctor Consultation Script
> "I'm seeking help for long-term effects I experienced after taking Zyprexa [duration] ago. 
> I've been experiencing [list 2-3 main symptoms]. Based on research showing Zyprexa can cause 
> receptor downregulation and metabolic damage, I'd like to discuss:
> 1. Testing for receptor function and metabolic health
> 2. Treatment options like betahistine and metabolic support
> 3. Referral to specialists familiar with antipsychotic damage"

### Adverse Event Report Template
> **Medication**: Olanzapine (Zyprexa)
> **Dates Taken**: [Start date] to [End date]
> **Dosage**: [Amount and frequency]
> **Adverse Effects Experienced**: [List all effects]
> **Duration of Effects**: [Ongoing/Resolved after X time]
> **Impact on Life**: [Describe quality of life changes]
> **Treatment Received**: [Any treatments for adverse effects]

### Media Pitch Template
> **Subject**: Survivor Story: How Zyprexa Caused Permanent Neurological Damage
> 
> I'm a Zyprexa survivor experiencing [brief description of effects]. My story represents 
> thousands of patients who weren't adequately warned about risks like [key risk]. 
> New research shows [scientific finding] that explains these effects. Eli Lilly has paid 
> over $2.6 billion in settlements for concealing these risks. I'd like to share my 
> experience to help others and demand accountability.

---

## 🔄 MAINTENANCE PLAN

### Daily Habits
- [ ] **Take supplements as prescribed**
- [ ] **Follow dietary protocol**
- [ ] **Exercise for 30 minutes**
- [ ] **Practice mindfulness/meditation**
- [ ] **Journal symptoms and mood**

### Weekly Habits
- [ ] **Review week's progress**
- [ ] **Plan meals for upcoming week**
- [ ] **Connect with support network**
- [ ] **Research new treatment options**

### Monthly Habits
- [ ] **Doctor follow-up appointments**
- [ ] **Update legal documentation**
- [ ] **Review advocacy progress**
- [ ] **Adjust treatment plan as needed**

---

**Remember**: Recovery is a journey, not a destination. Every step forward, no matter how small, is progress. You are not alone in this fight.

*This guide is for informational purposes only. Always consult with qualified healthcare providers before making changes to your treatment plan.*