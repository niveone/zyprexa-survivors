# Zyprexa Survivors Guide - Deployment Instructions

## 🚀 Quick Deployment Options

### Option 1: Vercel (Recommended)
1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import your GitHub repository
4. Vercel will automatically detect Next.js and deploy
5. Configure environment variables if needed

### Option 2: Netlify
1. Build the project: `npm run build`
2. Install Netlify CLI: `npm install -g netlify-cli`
3. Deploy: `netlify deploy --prod`

### Option 3: DigitalOcean App Platform
1. Push code to GitHub
2. Create new app in DigitalOcean dashboard
3. Connect GitHub repository
4. Configure:
   - Build Command: `npm run build`
   - Run Command: `npm start`
   - Node.js Version: 18.x or higher

## 📋 Pre-Deployment Steps

### 1. Install Dependencies
```bash
npm install
```

### 2. Build the Project
```bash
npm run build
```

### 3. Test Locally
```bash
npm start
```

## 🔧 Environment Variables

Create a `.env.production` file:
```env
NODE_ENV=production
PORT=3000
HOSTNAME=0.0.0.0
```

## 📦 Static Export (Optional)

If you want to deploy as a static site:
```bash
npm run export
```
This will create a `out` folder with static files.

## 🌐 Custom Domain Setup

### Vercel
1. Go to project settings
2. Add custom domain
3. Follow DNS instructions

### Netlify
1. Go to site settings
2. Add custom domain
3. Configure DNS

## 📊 Monitoring

### Vercel Analytics
- Enable in project settings
- Track performance and visitor metrics

### Netlify Analytics
- Available in paid plans
- Real-time visitor data

## 🚨 Troubleshooting

### Build Errors
1. Run `npm run lint` to check for issues
2. Clear Next.js cache: `rm -rf .next`
3. Rebuild: `npm run build`

### Runtime Errors
1. Check server logs
2. Verify environment variables
3. Ensure all dependencies are installed

## 📱 Mobile Optimization

The project is already responsive and optimized for mobile devices. Test on:
- iOS Safari
- Android Chrome
- Mobile browsers

## 🔒 Security

- All external links open in new tabs
- No sensitive data is stored client-side
- HTTPS is automatically configured by most platforms

## 📈 Performance

The project includes:
- Image optimization
- Code splitting
- Lazy loading
- Caching headers
- CDN integration (platform-dependent)

## 🎯 Post-Deployment

1. Test all features:
   - Document viewing
   - Download functionality
   - Social media sharing
   - Action buttons (Survey, Petition, Donate)

2. Monitor performance:
   - Page load times
   - Mobile responsiveness
   - Error rates

3. Set up analytics:
   - Google Analytics
   - Platform-specific analytics

## 💡 Tips

- For better SEO, add meta tags to `src/app/layout.tsx`
- Consider adding a sitemap for search engines
- Set up 404 page if needed
- Monitor broken links regularly