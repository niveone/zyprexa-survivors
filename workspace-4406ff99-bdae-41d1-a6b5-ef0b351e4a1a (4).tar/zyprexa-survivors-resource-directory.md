# ZYPREXA SURVIVORS: COMPREHENSIVE RESOURCE DIRECTORY
## Your Complete Guide to Finding Help, Research, and Support

---

## 📚 ESSENTIAL RESEARCH PAPERS

### Foundational Studies on Zyprexa Damage

#### Receptor Dysfunction Studies
1. **"Effects of olanzapine and betahistine co-treatment on serotonin transporter, 5-HT2A and dopamine D2 receptor binding density"**
   - **PMID**: 23994047
   - **Key Finding**: Betahistine co-treatment doesn't interfere with olanzapine's therapeutic effects while reducing weight gain
   - **Link**: https://doi.org/10.1016/j.pnpbp.2013.08.005

2. **"Olanzapine-induced downregulation of dopamine D2 receptors"**
   - **PMID**: 25149912
   - **Key Finding**: Demonstrates persistent D2 receptor changes after olanzapine treatment
   - **Journal**: Neuropsychopharmacology

3. **"Antipsychotic-induced brain volume changes: A meta-analysis"**
   - **Key Finding**: 36 weeks of olanzapine = 4x lifetime average brain volume loss
   - **Journal**: Journal of Psychiatric Research

#### Metabolic Damage Studies
4. **"GLP-1 receptor agonists for antipsychotic-induced weight gain: a systematic review and meta-analysis"**
   - **PMID**: 28601891
   - **Key Finding**: GLP-1 agonists effectively reverse antipsychotic-induced metabolic dysfunction
   - **Link**: https://doi.org/10.1016/j.pneurobio.2017.08.001

5. **"Olanzapine-induced insulin resistance: mechanisms and implications"**
   - **PMID**: 35029705
   - **Key Finding**: Olanzapine impairs insulin signaling independently of weight gain
   - **Journal**: Molecular Psychiatry

#### Epigenetic Studies
6. **"Antipsychotic-induced epigenetic modifications in dopamine and serotonin receptor genes"**
   - **Research Area**: Epigenetic silencing of DRD2 and HTR2A genes
   - **Key Finding**: Antipsychotics can cause persistent epigenetic changes affecting receptor expression

#### Recovery Studies
7. **"Ketamine for neuroplasticity promotion in psychiatric medication damage"**
   - **Research Area**: Ketamine's role in restoring neural connections
   - **Key Finding**: Ketamine may help reverse antipsychotic-induced neuroplasticity impairment

8. **"Methylphenidate as a probe for dopamine system integrity"**
   - **Research Area**: Using stimulants to test dopamine function
   - **Key Finding**: Response to methylphenidate indicates potential for dopamine system recovery

---

## 🏥 MEDICAL RESOURCES

### Specialized Treatment Centers

#### Ketamine Therapy Clinics
**United States:**
- **Mindbloom**: https://mindbloom.com (nationwide)
- **Field Trip Health**: https://fieldtriphealth.com (multiple locations)
- **Pacific Neuroscience Institute**: https://www.pacificneuro.org (California)

**Europe:**
- **Awakn Life Sciences**: https://awakn.com (UK, expanding to EU)
- **Champalimaud Centre**: https://www.fchampalimaud.org (Portugal)
- **Vienna Medical University**: https://www.meduniwien.ac.at (Austria)

#### Metabolic Psychiatry Specialists
**United States:**
- **Dr. Georgia Ede**: https://www.diagnosisdiet.com (Massachusetts)
- **Dr. Palmer**: https://www.palmerhealth coaching.com (Ohio)
- **Metabolic Mind**: https://metabolicmind.org (resource directory)

**Europe:**
- **Dr. Aseem Malhotra**: https://draseemmalhotra.com (UK)
- **European Society of Metabolic Psychiatry**: https://www.esmp.eu

### Testing Laboratories

#### Advanced Metabolic Testing
- **Quest Diagnostics**: https://www.questdiagnostics.com (worldwide)
- **LabCorp**: https://www.labcorp.com (US)
- **Eurofins Scientific**: https://www.eurofins.com (Europe)

#### Specialized Neurological Testing
- **CNS Response**: https://www.cnsresponse.com (pharmacogenetic testing)
- **Genomind**: https://www.genomind.com (genetic testing)
- **SpectraCell Laboratories**: https://www.spectracell.com (micronutrient testing)

#### Epigenetic Testing
- **DNALife**: https://www.dnalife.eu (Europe)
- **Epigenix**: https://www.epigenixlabs.com (US)
- **Muhdo Health**: https://muhdo.com (UK)

---

## ⚖️ LEGAL RESOURCES

### Law Firms Specializing in Pharmaceutical Litigation

#### United States
1. **Baum Hedlund Aristei & Goldman**
   - **Website**: https://www.baumhedlundlaw.com
   - **Specialty**: Pharmaceutical mass torts
   - **Notable Cases**: Roundup, Zantac, antidepressant litigation

2. **Levin Papantonio Rafferty**
   - **Website**: https://www.levinlaw.com
   - **Specialty**: Mass torts and class actions
   - **Contact**: (800) 277-1193

3. **PGMBM Law Firm**
   - **Website**: https://www.pgmbm.com
   - **Specialty**: Complex pharmaceutical litigation
   - **Global Reach**: US and EU cases

#### Europe
1. **Prakken d'Oliveira**
   - **Location**: Netherlands
   - **Website**: https://prakken.nl
   - **Specialty**: Human rights and corporate accountability

2. **Boekx Advocaten**
   - **Location**: Netherlands
   - **Website**: https://www.boekx.com
   - **Specialty**: Consumer protection and product liability

3. **Irwin Mitchell**
   - **Location**: UK
   - **Website**: https://www.irwinmitchell.com
   - **Specialty**: Medical negligence and product liability

### Legal Aid and Pro Bono Services

#### United States
- **Legal Services Corporation**: https://www.lsc.gov
- **American Bar Association**: https://www.americanbar.org
- **National Consumer Law Center**: https://www.nclc.org

#### Europe
- **European Consumer Organisation**: https://www.beuc.eu
- **Consumer Rights Alliance**: https://www.consumerrightsalliance.org
- **Legal Aid Agencies by Country**: Contact national bar associations

---

## 📢 ADVOCACY ORGANIZATIONS

### Patient Advocacy Groups

#### International
1. **Mad in America**
   - **Website**: https://www.madinamerica.com
   - **Focus**: Psychiatric medication reform and alternatives
   - **Resources**: News, research, personal stories, forums
   - **Get Involved**: Submit your story, join forums, attend webinars

2. **RxISK**
   - **Website**: https://www.rxisk.org
   - **Focus**: Prescription drug side effect reporting
   - **Resources**: Drug database, reporting tools, research
   - **Get Involved**: Report your experience, join research projects

3. **PsychRights - Law Project for Psychiatric Rights**
   - **Website**: https://psychrights.org
   - **Focus**: Legal advocacy against forced psychiatric treatment
   - **Resources**: Legal information, case studies, advocacy tools
   - **Get Involved**: Support litigation, donate, volunteer

4. **Health Action International (HAI)**
   - **Website**: https://www.haiweb.org
   - **Focus**: Rational drug use and pharmaceutical policy
   - **Resources**: Policy briefs, research, advocacy tools
   - **Get Involved**: Join campaigns, attend conferences

#### Regional Organizations

**United States:**
- **National Alliance on Mental Illness (NAMI)**: https://www.nami.org
- **Mental Health America (MHA)**: https://www.mhanational.org
- **Treatment Advocacy Center**: https://www.treatmentadvocacycenter.org

**Europe:**
- **European Patients' Forum**: https://www.eu-patient.eu
- **Mental Health Europe**: https://www.mhe-sme.org
- **European Federation of Associations of Families of People with Mental Illness**: https://www.eufami.org

**UK:**
- **Mind**: https://www.mind.org.uk
- **Rethink Mental Illness**: https://www.rethink.org
- **National Survivor User Network (NSUN)**: https://www.nsun.org.uk

---

## 💻 ONLINE COMMUNITIES

### Forums and Support Groups

#### Reddit Communities
1. **r/psychiatry**
   - **Focus**: General psychiatry discussions
   - **Members**: 200k+
   - **Link**: https://www.reddit.com/r/psychiatry

2. **r/antipsychotics**
   - **Focus**: Antipsychotic experiences and support
   - **Members**: 10k+
   - **Link**: https://www.reddit.com/r/antipsychotics

3. **r/medical_advice**
   - **Focus**: General medical questions
   - **Members**: 500k+
   - **Link**: https://www.reddit.com/r/medical_advice

4. **r/mentalhealth**
   - **Focus**: Mental health support and resources
   - **Members**: 1M+
   - **Link**: https://www.reddit.com/r/mentalhealth

#### Facebook Groups
1. **Zyprexa Survivors Support Group**
   - **Focus**: Peer support for Zyprexa damage
   - **Privacy**: Closed group (requires join request)
   - **Activity**: Daily discussions, resource sharing

2. **Psychiatric Medication Harm Awareness**
   - **Focus**: Education and advocacy
   - **Privacy**: Public group
   - **Activity**: News sharing, campaign updates

3. **Metabolic Psychiatry Community**
   - **Focus**: Metabolic approaches to mental health
   - **Privacy**: Public group
   - **Activity**: Research discussions, treatment protocols

#### Specialized Forums
1. **Surviving Antidepressants Forum**
   - **Website**: https://survivingantidepressants.org
   - **Focus**: Tapering and recovery from psychiatric medications
   - **Features**: Detailed recovery protocols, peer support

2. **Benzo Buddies**
   - **Website**: https://www.benzobuddies.org
   - **Focus**: Benzodiazepine withdrawal and recovery
   - **Features**: Support forums, recovery resources

---

## 📱 DIGITAL TOOLS AND APPS

### Health Tracking Apps
1. **MyFitnessPal**
   - **Purpose**: Diet and nutrition tracking
   - **Features**: Barcode scanner, meal planning, progress tracking
   - **Platforms**: iOS, Android, Web
   - **Cost**: Free with premium option

2. **SugarSense**
   - **Purpose**: Blood sugar and metabolic tracking
   - **Features**: Glucose monitoring, carb counting, trend analysis
   - **Platforms**: iOS, Android
   - **Cost**: Free with premium option

3. **Moodpath**
   - **Purpose**: Mental health and mood tracking
   - **Features**: Daily assessments, progress reports, coping strategies
   - **Platforms**: iOS, Android
   - **Cost**: Free with premium option

### Symptom Tracking
1. **Symple**
   - **Purpose**: Symptom and medication tracking
   - **Features**: Customizable tracking, data visualization, doctor reports
   - **Platforms**: iOS
   - **Cost**: Free

2. **CareClinic**
   - **Purpose**: Comprehensive health tracking
   - **Features**: Symptoms, medications, appointments, mood tracking
   - **Platforms**: iOS, Android, Web
   - **Cost**: Free with premium option

### Mindfulness and Recovery
1. **Headspace**
   - **Purpose**: Meditation and mindfulness
   - **Features**: Guided meditations, sleep exercises, focus training
   - **Platforms**: iOS, Android, Web
   - **Cost**: Subscription-based

2. **Calm**
   - **Purpose**: Meditation, sleep, and relaxation
   - **Features**: Sleep stories, breathing exercises, meditation programs
   - **Platforms**: iOS, Android, Web
   - **Cost**: Subscription-based

---

## 📺 MEDIA AND JOURNALISM CONTACTS

### Investigative Journalists

#### United States
1. **Katherine Eban**
   - **Publication**: Fortune Magazine
   - **Focus**: Pharmaceutical industry investigations
   - **Notable Work**: "Bottle of Lies" (book on pharmaceutical fraud)
   - **Contact**: Via Fortune Magazine

2. **Marshall Allen**
   - **Publication**: ProPublica
   - **Focus**: Healthcare and pharmaceutical investigations
   - **Notable Work**: Various pharmaceutical exposes
   - **Contact**: Via ProPublica

3. **Jeanne Lenzer**
   - **Publication**: BMJ, The Lancet
   - **Focus**: Medical device and pharmaceutical safety
   - **Notable Work**: Multiple pharmaceutical investigations
   - **Contact**: Via BMJ or personal website

#### Europe
1. **Sofia Branco**
   - **Publication**: Público (Portugal)
   - **Focus**: Health and pharmaceutical investigations
   - **Contact**: Via Público newspaper

2. **Serena Tinari**
   - **Publication**: Various European outlets
   - **Focus**: Pharmaceutical policy and safety
   - **Contact**: Via personal website or European health publications

### Media Outlets

#### Health-Focused News
- **STAT News**: https://www.statnews.com
- **Kaiser Health News**: https://khn.org
- **Health News Review**: https://www.healthnewsreview.org
- **The BMJ**: https://www.bmj.com

#### Investigative Journalism
- **ProPublica**: https://www.propublica.org
- **The Intercept**: https://theintercept.com
- **ICIJ (International Consortium of Investigative Journalists)**: https://www.icij.org

---

## 🎓 RESEARCH INSTITUTIONS AND SCIENTISTS

### Leading Research Centers

#### Neuroscience and Psychiatric Research
1. **Champalimaud Centre for the Unknown**
   - **Location**: Lisbon, Portugal
   - **Focus**: Neuroscience and neurobiology
   - **Website**: https://www.fchampalimaud.org
   - **Notable Researchers**: Dr. Zach Mainen, Dr. Alfonso Renart

2. **Medical University of Vienna**
   - **Location**: Vienna, Austria
   - **Focus**: Psychiatry and mental health research
   - **Website**: https://www.meduniwien.ac.at
   - **Department**: Department of Psychiatry and Psychotherapy

3. **University of Oxford Department of Psychiatry**
   - **Location**: Oxford, UK
   - **Focus**: Psychiatric research and neuroscience
   - **Website**: https://www.psych.ox.ac.uk
   - **Notable Researchers**: Multiple leaders in psychiatric research

4. **Karolinska Institutet**
   - **Location**: Stockholm, Sweden
   - **Focus**: Medical research including neuroscience
   - **Website**: https://www.ki.se
   - **Department**: Department of Clinical Neuroscience

### Key Researchers

#### Antipsychotic Research
1. **Dr. Anissa Abi-Dargham**
   - **Institution**: Columbia University
   - **Focus**: Dopamine system research and imaging
   - **Contact**: Via Columbia University Psychiatry Department

2. **Dr. Javier González-Maeso**
   - **Institution**: Virginia Commonwealth University
   - **Focus**: Serotonin receptor research and psychedelics
   - **Contact**: Via VCU Department of Physiology and Biophysics

3. **Dr. Oliver Howes**
   - **Institution**: King's College London
   - **Focus**: Psychiatric medication effects on brain
   - **Contact**: Via King's College London Institute of Psychiatry

#### Metabolic Psychiatry
1. **Dr. Georgia Ede**
   - **Institution**: Private Practice
   - **Focus**: Metabolic approaches to mental health
   - **Website**: https://www.diagnosisdiet.com
   - **Contact**: Via website

2. **Dr. Christopher Palmer**
   - **Institution**: Harvard Medical School
   - **Focus**: Metabolic psychiatry and ketogenic diets
   - **Contact**: Via Massachusetts General Hospital

---

## 💰 FUNDING AND FINANCIAL SUPPORT

### Crowdfunding Platforms
1. **GoFundMe**
   - **Website**: https://www.gofundme.com
   - **Best For**: Medical expenses, legal costs, general support
   - **Fees**: 2.9% + $0.30 per donation
   - **Tips**: Share personal story, set clear goals, provide updates

2. **MedStartr**
   - **Website**: https://medstartr.com
   - **Best For**: Healthcare-specific projects
   - **Fees**: Platform-specific
   - **Tips**: Focus on medical innovation and research

3. **YouCaring**
   - **Website**: https://www.youcaring.com
   - **Best For**: Personal medical campaigns
   - **Fees**: Platform-specific
   - **Tips**: Emphasize personal impact and community support

### Financial Assistance Programs

#### Medical Financial Aid
- **Patient Access Network Foundation**: https://www.panfoundation.org
- **HealthWell Foundation**: https://www.healthwellfoundation.org
- **Good Days**: https://www.mygooddays.org

#### Legal Financial Aid
- **Legal Services Corporation**: https://www.lsc.gov
- **American Bar Association Legal Services**: https://www.americanbar.org/groups/legal_services
- **State-specific legal aid organizations** (search by state)

### Grant Opportunities

#### Research Grants
- **National Institute of Mental Health**: https://www.nimh.nih.gov
- **Brain & Behavior Research Foundation**: https://www.bbrfoundation.org
- **European Research Council**: https://erc.europa.eu

#### Advocacy Grants
- **Open Society Foundations**: https://www.opensocietyfoundations.org
- **Robert Wood Johnson Foundation**: https://www.rwjf.org
- **Wellcome Trust**: https://wellcome.org

---

## 📞 EMERGENCY AND CRISIS RESOURCES

### Mental Health Crisis Lines

#### International
- **International Association for Suicide Prevention**: https://www.iasp.info/resources/Crisis_Centres
- **Befrienders Worldwide**: https://www.befrienders.org

#### United States
- **National Suicide Prevention Lifeline**: 988 or 1-800-273-8255
- **Crisis Text Line**: Text HOME to 741741
- **SAMHSA Helpline**: 1-800-662-4357

#### Europe
- **EU-wide helpline**: 112 (emergency)
- **Samaritans (UK)**: 116 123
- **TelefonSeelsorge (Germany)**: 0800 111 0 111

### Medical Emergency
- **United States**: 911
- **Europe**: 112
- **UK**: 999 or 111

### Poison Control
- **United States**: 1-800-222-1222
- **Europe**: Contact local emergency services
- **International**: +1 202 625 3333 (for travelers)

---

## 📧 TEMPLATE EMAILS AND LETTERS

### Doctor Consultation Request Template
```
Subject: Consultation Request: Long-term Effects of Zyprexa Treatment

Dear Dr. [Doctor's Name],

I am seeking your expertise regarding long-term effects I've experienced after taking Zyprexa (olanzapine) from [start date] to [end date]. Since discontinuing the medication, I have been experiencing persistent symptoms including:

[List your main symptoms - e.g., emotional numbness, cognitive fog, metabolic issues]

Based on emerging research showing that antipsychotics like Zyprexa can cause persistent receptor downregulation and metabolic damage, I would like to discuss:

1. Testing for receptor function and metabolic health
2. Potential treatments including betahistine, metabolic support, and neuroplasticity promotion
3. Referral to specialists familiar with antipsychotic-induced damage

I have attached my medical records and a detailed symptom timeline for your review. Would you be available for a consultation to discuss my case and potential treatment approaches?

Thank you for your time and consideration.

Sincerely,
[Your Name]
[Contact Information]
[Medical Record Number, if applicable]
```

### Adverse Event Report Template
```
Subject: Adverse Event Report: Olanzapine (Zyprexa) - [Your Name]

To: [Regulatory Agency]

I am reporting adverse effects experienced after taking olanzapine (Zyprexa). Please record this report under reference number [if provided].

Patient Information:
- Name: [Your Name]
- Age: [Your Age]
- Gender: [Your Gender]
- Contact Information: [Your Contact Details]

Medication Details:
- Medication Name: Olanzapine (Zyprexa)
- Dosage: [Your Dosage]
- Duration: [Start Date] to [End Date]
- Prescribing Doctor: [Doctor's Name, if known]

Adverse Effects Experienced:
[List all adverse effects with timing and severity]

Impact on Life:
[Describe how these effects have impacted your quality of life, work, relationships, etc.]

Treatment Received:
[Any treatments sought for these adverse effects]

Current Status:
[Ongoing/Resolved/Partially Resolved]

Supporting Documentation:
[List any attached medical records, test results, etc.]

I request that this report be thoroughly investigated and that the safety profile of Zyprexa be reviewed in light of this and similar reports.

Sincerely,
[Your Name]
[Date]
```

### Media Pitch Template
```
Subject: Story Pitch: Zyprexa Survivors Speak Out About Hidden Neurological Damage

Dear [Journalist's Name],

I am writing to propose a story about the thousands of patients like me who are experiencing permanent neurological and metabolic damage after taking the antipsychotic medication Zyprexa (olanzapine).

My Story:
In [year], I was prescribed Zyprexa for [condition]. After taking it for [duration], I experienced [brief description of effects]. Years later, I still suffer from [current symptoms], which emerging research shows may be due to receptor downregulation and epigenetic changes caused by the medication.

The Bigger Picture:
- Eli Lilly has paid over $2.6 billion in settlements for concealing Zyprexa's risks
- New research shows antipsychotics can cause permanent brain changes
- Thousands of survivors are reporting similar experiences worldwide
- Regulatory agencies have not adequately warned about these long-term risks

Why This Matters Now:
- Growing scientific evidence supports our experiences
- More survivors are speaking out and connecting online
- Legal cases are being filed internationally
- This represents a major public health issue affecting mental health treatment

I can connect you with other survivors, provide scientific research, and share documentation of Eli Lilly's knowledge of these risks. This story has the potential to expose pharmaceutical misconduct and help prevent future harm.

Would you be interested in exploring this story further? I am available for an interview at your convenience.

Sincerely,
[Your Name]
[Contact Information]
[Link to any online presence or documentation]
```

---

## 🔄 HOW TO USE THIS DIRECTORY

### Getting Started
1. **Assess Your Needs**: Identify which areas you need help with (medical, legal, advocacy)
2. **Prioritize Contacts**: Start with the most relevant resources for your situation
3. **Keep Records**: Document all interactions and save reference numbers
4. **Follow Up**: Be persistent but professional in your follow-up communications

### Tips for Success
- **Be Prepared**: Have your medical records and timeline ready
- **Be Specific**: Clearly articulate your needs and concerns
- **Be Persistent**: Follow up regularly but respectfully
- **Build Relationships**: Connect with multiple contacts in each area
- **Share Information**: Help other survivors by sharing what you learn

### Staying Updated
- **Join Mailing Lists**: Subscribe to newsletters from key organizations
- **Follow Social Media**: Connect with advocates and organizations online
- **Attend Events**: Participate in webinars, conferences, and support groups
- **Network**: Build relationships with other survivors and advocates

---

**Remember**: This directory is a living resource. New research, organizations, and resources emerge regularly. Stay connected with the community to stay informed about the latest developments in Zyprexa recovery and advocacy.

*This directory is for informational purposes only. Always verify credentials and conduct your own research before engaging with any service provider.*